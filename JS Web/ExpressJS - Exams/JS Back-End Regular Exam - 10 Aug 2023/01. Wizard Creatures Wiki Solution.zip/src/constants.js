exports.PORT = 3000;
exports.DB_Connection_String = 'mongodb://localhost:27017/wizard-creature-wiki';
exports.JWT_Secret = 'qwertyuiopasdfghjklzxcvbnm123456';
exports.AUTH_COOKIE_NAME = 'auth_jwt';